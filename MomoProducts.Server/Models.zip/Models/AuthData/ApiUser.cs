﻿namespace MomoProducts.Server.Models.AuthData
{
    public class ApiUser
    {
        public string ReferenceId { get; set; }
    }
}
