﻿namespace MomoProducts.Server.Models.AuthData
{
    public class ApiKey
    {
        public string APIKey { get; set; }
    }
}
