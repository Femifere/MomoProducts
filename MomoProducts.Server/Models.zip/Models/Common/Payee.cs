﻿namespace MomoProducts.Server.Models.Common
{
    public class Payee
    {
        public string PartyIdType { get; set; }

        public string PartyId { get; set; }
    }
}
