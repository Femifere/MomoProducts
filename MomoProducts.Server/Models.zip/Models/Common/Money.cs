﻿namespace MomoProducts.Server.Models.Common
{
    public class Money
    {
        public string Amount { get; set; }

        public string Currency { get; set; }
    }
}
