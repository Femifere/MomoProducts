﻿namespace MomoProducts.Server.Models.Common
{
    public class Payer
    {
        public string PartyIdType { get; set; }

        public string PartyId { get; set; }
    }
}
